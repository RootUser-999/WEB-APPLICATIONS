document.getElementById("btn").onclick = function() {
    const input = document.getElementById("input").value; 
    const div = document.getElementById("div2");
    let images = [];
    
    div.innerHTML = "";  

    for (let i = 0; i < input; i++) {
        const rand = Math.floor(Math.random() * 6 + 1); 
        images.push(`<img src="${rand}.png" width="100" height="100">`); 
    }
    
    div.innerHTML = images.join(''); 
};
